const initState={}

const projectReducer=(state=initState,action)=>{
return state;
}

export default projectReducer;